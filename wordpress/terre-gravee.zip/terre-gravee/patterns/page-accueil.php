<?php
/**
 * Title: Page complète · Accueil
 * Slug: terre-gravee/page-accueil
 * Categories: terre-gravee-pages
 * Post Types: page
 * Description: Toute la page « Accueil » de la maquette v4, prête à insérer dans une page vide.
 * Inserter: true
 *
 * @package TerreGravee
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"noel tg-quand tg-quand-avant tg-quand-pendant","anchor":"noel"} -->
<section id="noel" class="wp-block-group noel tg-quand tg-quand-avant tg-quand-pendant">
<!-- wp:group {"className":"noel__panneau"} -->
<div class="wp-block-group noel__panneau">
<!-- wp:group {"className":"wrap noel__grille"} -->
<div class="wp-block-group wrap noel__grille">
<!-- wp:group {"className":"noel__texte"} -->
<div class="wp-block-group noel__texte">
<!-- wp:paragraph {"className":"noel__enseigne"} -->
<p class="noel__enseigne"><span class="noel__decoupe">Noël</span> <span class="noel__millesime">2026 · Idées cadeaux</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"titre-noel"} -->
<h2 id="titre-noel" class="wp-block-heading">Offrir les Pyrénées pour Noël</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"noel__offre-bloc"} -->
<div class="wp-block-group noel__offre-bloc">
<!-- wp:paragraph {"className":"noel__offre"} -->
<p class="noel__offre"><span class="tg-quand tg-quand-avant">À partir du 27 novembre : livraison offerte et un magnet en ardoise gravée offert dans chaque colis, jusqu’au 14 décembre. Aujourd’hui, la livraison coûte encore 5 €.</span><span class="tg-quand tg-quand-pendant">Livraison offerte et un magnet en ardoise gravée offert dans chaque colis jusqu’au 14 décembre</span></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"noel__limite"} -->
<p class="noel__limite">Pour recevoir avant Noël, commandez au plus tard le lundi 14 décembre.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"noel__actions"} -->
<p class="noel__actions"><a class="btn" href="/produits/#cadeaux">Toutes les idées cadeaux</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"noel__vitrine"} -->
<div class="wp-block-group noel__vitrine">
<!-- wp:html -->
<figure class="noel__oeuvre">
          <div class="noel__niche"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-dore-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-dore-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-dore-880.webp 880w" sizes="(max-width: 900px) 40vw, 230px" width="440" height="873" alt="Simulation : plaque Le Pic du Midi dorée, rétroéclairée en blanc chaud" loading="eager" decoding="async"></div></div>
          <figcaption class="noel__cartel">Simulation · Le Pic du Midi, finition dorée, LED blanc chaud</figcaption>
        </figure>
<!-- /wp:html -->

<!-- wp:group {"className":"noel__led"} -->
<div class="wp-block-group noel__led">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/produits/led/">Le kit LED</a> <span>+ 15 €</span></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En option sur la fiche de chaque plaque. L’atelier le colle au dos : le soir, la plaque s’allume, par exemple en blanc chaud. Simulation ci-dessus.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"noel__cadeau"} -->
<div class="wp-block-group noel__cadeau">
<!-- wp:html -->
<a class="noel__cadeau-visuel" href="/produits/carte-cadeau/" tabindex="-1" aria-hidden="true"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>misc/carte-cadeau.webp" width="720" height="720" alt="" loading="lazy" decoding="async"></a>
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="/produits/carte-cadeau/">La carte cadeau</a> <span>65 €</span></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Une plaque au choix, valable 2 ans. La carte cadeau numérique est envoyée par e-mail, sans frais de port : la bonne solution si la date limite d’envoi est passée.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<svg class="noel__sommets" viewBox="0 0 1440 240" preserveAspectRatio="xMidYMax slice" aria-hidden="true" focusable="false">
  <defs><linearGradient id="noel-crete-lointain" gradientUnits="userSpaceOnUse" x1="0" y1="60" x2="0" y2="240"><stop offset="0" class="noel__stop-lointain-haut"/><stop offset="1" class="noel__stop-lointain-bas"/></linearGradient><clipPath id="noel-decoupe-lointain"><path d="M0 128 L40 118 L84 124 L130 100 L160 108 L206 80 L236 90 L270 72 L300 84 L338 78 L380 104 L430 96 L470 112 L520 88 L556 96 L600 70 L628 78 L664 60 L690 66 L720 62 L760 90 L800 84 L846 104 L890 92 L930 100 L972 76 L1004 84 L1040 66 L1066 74 L1100 70 L1140 98 L1190 90 L1236 108 L1280 86 L1316 94 L1360 80 L1400 96 L1440 90 L1440 240 L0 240 Z"/></clipPath><linearGradient id="noel-neige-lointain" gradientUnits="userSpaceOnUse" x1="0" y1="82" x2="0" y2="110"><stop offset="0" class="noel__stop-neige"/><stop offset="1" class="noel__stop-neige-fin"/></linearGradient><linearGradient id="noel-crete-loin" gradientUnits="userSpaceOnUse" x1="0" y1="124" x2="0" y2="240"><stop offset="0" class="noel__stop-loin-haut"/><stop offset="1" class="noel__stop-loin-bas"/></linearGradient><clipPath id="noel-decoupe-loin"><path d="M0 170 L60 154 L110 162 L170 136 L210 146 L256 126 L300 140 L350 150 L410 132 L450 140 L500 124 L540 134 L600 156 L660 146 L720 160 L780 138 L820 146 L870 128 L910 140 L960 158 L1020 146 L1080 154 L1130 132 L1170 140 L1220 124 L1262 136 L1310 154 L1370 144 L1440 152 L1440 240 L0 240 Z"/></clipPath><linearGradient id="noel-neige-loin" gradientUnits="userSpaceOnUse" x1="0" y1="122" x2="0" y2="150"><stop offset="0" class="noel__stop-neige"/><stop offset="1" class="noel__stop-neige-fin"/></linearGradient></defs>
  <path fill="url(#noel-crete-lointain)" d="M0 128 L40 118 L84 124 L130 100 L160 108 L206 80 L236 90 L270 72 L300 84 L338 78 L380 104 L430 96 L470 112 L520 88 L556 96 L600 70 L628 78 L664 60 L690 66 L720 62 L760 90 L800 84 L846 104 L890 92 L930 100 L972 76 L1004 84 L1040 66 L1066 74 L1100 70 L1140 98 L1190 90 L1236 108 L1280 86 L1316 94 L1360 80 L1400 96 L1440 90 L1440 240 L0 240 Z"/>
  <path class="noel__neige" fill="url(#noel-neige-lointain)" clip-path="url(#noel-decoupe-lointain)" d="M0 0 L1440 0 L1440 90 L1416 103 L1392 106 L1368 92 L1344 88 L1320 103 L1296 107 L1272 92 L1248 88 L1224 102 L1200 106 L1176 94 L1152 91 L1128 99 L1104 103 L1080 97 L1056 94 L1032 96 L1008 99 L984 101 L960 98 L936 92 L912 96 L888 105 L864 101 L840 89 L816 93 L792 107 L768 102 L744 88 L720 92 L696 107 L672 103 L648 89 L624 92 L600 105 L576 102 L552 92 L528 93 L504 100 L480 101 L456 97 L432 95 L408 95 L384 100 L360 102 L336 96 L312 90 L288 99 L264 107 L240 96 L216 87 L192 98 L168 108 L144 97 L120 87 L96 98 L72 108 L48 98 L24 89 L0 97 Z"/>
  <path fill="url(#noel-crete-loin)" d="M0 170 L60 154 L110 162 L170 136 L210 146 L256 126 L300 140 L350 150 L410 132 L450 140 L500 124 L540 134 L600 156 L660 146 L720 160 L780 138 L820 146 L870 128 L910 140 L960 158 L1020 146 L1080 154 L1130 132 L1170 140 L1220 124 L1262 136 L1310 154 L1370 144 L1440 152 L1440 240 L0 240 Z"/>
  <path class="noel__neige" fill="url(#noel-neige-loin)" clip-path="url(#noel-decoupe-loin)" d="M0 0 L1440 0 L1440 131 L1416 130 L1392 142 L1368 144 L1344 134 L1320 132 L1296 139 L1272 141 L1248 138 L1224 135 L1200 134 L1176 138 L1152 143 L1128 138 L1104 130 L1080 136 L1056 147 L1032 140 L1008 127 L984 135 L960 148 L936 141 L912 127 L888 134 L864 147 L840 141 L816 129 L792 134 L768 144 L744 141 L720 134 L696 134 L672 139 L648 140 L624 139 L600 134 L576 133 L552 141 L528 144 L504 134 L480 129 L456 141 L432 147 L408 134 L384 127 L360 140 L336 148 L312 135 L288 128 L264 139 L240 146 L216 136 L192 130 L168 138 L144 143 L120 139 L96 135 L72 135 L48 138 L24 141 L0 139 Z"/>
  <path class="noel__crete-pres" d="M0 214 L90 196 L170 204 L260 182 L340 196 L430 188 L520 204 L610 192 L700 206 L790 194 L880 200 L980 184 L1070 198 L1160 190 L1250 204 L1340 192 L1440 200 L1440 240 L0 240 Z"/>
</svg>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"noel__mur"} -->
<div class="wp-block-group noel__mur">
<!-- wp:group {"className":"wrap noel__plaques"} -->
<div class="wp-block-group wrap noel__plaques">
<!-- wp:heading {"level":3,"className":"noel__sous-titre"} -->
<h3 class="wp-block-heading noel__sous-titre">Quatre plaques à offrir <span>65 € · noir, gris ou doré</span></h3>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[tg_produits slugs="le-pic-du-midi,lours,lisard,le-cerf" finitions="le-pic-du-midi:noir,lours:noir,lisard:dore,le-cerf:gris"]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"heros"} -->
<section class="wp-block-group heros">
<!-- wp:group {"className":"wrap heros__grille"} -->
<div class="wp-block-group wrap heros__grille">
<!-- wp:group {"className":"heros__texte"} -->
<div class="wp-block-group heros__texte">
<!-- wp:paragraph {"className":"surtitre"} -->
<p class="surtitre">Plaques murales en aluminium · Hautes-Pyrénées</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Graver l’âme des territoires</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"heros__intro"} -->
<p class="heros__intro">Terre Gravée fabrique des plaques de décoration murale en aluminium inspirées des Hautes-Pyrénées : le Pic du Midi, l’isard, la tour des Jacobins… Douze modèles dessinés par Maude Villatte et Lola Jacquet pour le décor d’Aquensis, découpés au laser à Revel et thermolaqués à Bagnères-de-Bigorre.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"heros__actions"} -->
<div class="wp-block-group heros__actions">
<!-- wp:html -->
<a class="btn" href="/produits/">Voir la collection</a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="btn btn--ligne" href="/carte-des-lieux/">La carte des lieux</a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<dl class="faits">
        <div><dt>Format</dt><dd>60 × 30 cm</dd></div>
        <div><dt>Finitions</dt><dd>Noir, gris, doré</dd></div>
        <div><dt>Prix</dt><dd>65 €</dd></div>
      </dl>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="mur-expo" data-mur>
      <figure class="accroche accroche--a"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-noir-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-noir-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-noir-880.webp 880w" sizes="(max-width: 900px) 27vw, 170px" width="440" height="873" alt="Plaque Le Pic du Midi, finition noire" fetchpriority="high" decoding="async"></div><figcaption class="cartel"><span class="cartel__nom">Le Pic du Midi</span><span class="cartel__sep"> · </span><span class="cartel__detail">2 877 m</span></figcaption></figure><figure class="accroche accroche--b"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lisard-dore-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lisard-dore-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lisard-dore-880.webp 880w" sizes="(max-width: 900px) 27vw, 170px" width="440" height="871" alt="Plaque L’Isard, finition dorée" fetchpriority="high" decoding="async"></div><figcaption class="cartel"><span class="cartel__nom">L’Isard</span><span class="cartel__sep"> · </span><span class="cartel__detail"><i>Rupicapra pyrenaica</i></span></figcaption></figure><figure class="accroche accroche--c"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-tour-des-jacobins-gris-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-tour-des-jacobins-gris-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-tour-des-jacobins-gris-880.webp 880w" sizes="(max-width: 900px) 27vw, 170px" width="440" height="856" alt="Plaque La Tour des Jacobins, finition grise" fetchpriority="high" decoding="async"></div><figcaption class="cartel"><span class="cartel__nom">La Tour des Jacobins</span><span class="cartel__sep"> · </span><span class="cartel__detail">Bagnères</span></figcaption></figure>
      <div class="mur-expo__legende">
        <div class="led-commandes">
          <button type="button" class="interrupteur" aria-pressed="false"><span class="interrupteur__voyant" aria-hidden="true"></span><span class="interrupteur__texte">Allumer le rétroéclairage</span></button>
          <div class="led-couleurs" role="group" aria-label="Couleur des LED" hidden><button type="button" style="--c:#FFD39A" data-couleur="#FFD39A" aria-pressed="true" title="Blanc chaud"><span class="visuellement-cache">Blanc chaud</span></button><button type="button" style="--c:#5AB0FF" data-couleur="#5AB0FF" aria-pressed="false" title="Bleu"><span class="visuellement-cache">Bleu</span></button><button type="button" style="--c:#63E58F" data-couleur="#63E58F" aria-pressed="false" title="Vert"><span class="visuellement-cache">Vert</span></button><button type="button" style="--c:#B48CFF" data-couleur="#B48CFF" aria-pressed="false" title="Violet"><span class="visuellement-cache">Violet</span></button><button type="button" style="--c:#FF8A57" data-couleur="#FF8A57" aria-pressed="false" title="Orange"><span class="visuellement-cache">Orange</span></button></div>
        </div>
        <a class="mur-expo__note" href="/produits/led/">Simulation · kit LED en option, 15 €</a>
      </div>
    </div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"reperes"} -->
<section class="wp-block-group reperes">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><strong>160 km</strong><span>Découpe, laquage et expédition dans un rayon de 160 km autour de Bagnères-de-Bigorre.</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><strong>Laser</strong><span>Aluminium découpé au laser puis thermolaqué, en Occitanie.</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><strong>0 perçage</strong><span>Deux fixations Command™ de 3M fournies avec la plaque : des languettes qui s’emboîtent comme un scratch.</span></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><strong>2 à 4 jours</strong><span>Expédition sous 2 à 4 jours ouvrés.</span></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section"} -->
<section class="wp-block-group section">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"entete-section entete-section\u002d\u002dligne"} -->
<div class="wp-block-group entete-section entete-section--ligne">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"surtitre"} -->
<p class="surtitre">La collection</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Trois thèmes, douze plaques</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<a class="lien-fleche" href="/produits/">Toute la collection</a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"collections"} -->
<div class="wp-block-group collections">
<!-- wp:html -->
<a class="tuile" href="/produits/#paysages">
  <div class="tuile__mur" aria-hidden="true"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-noir-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-noir-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-pic-du-midi-noir-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="873" alt="Plaque Le Pic du Midi, finition noire" loading="lazy" decoding="async"></div><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-cirque-de-gavarnie-dore-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-cirque-de-gavarnie-dore-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-cirque-de-gavarnie-dore-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="857" alt="Plaque Le Cirque de Gavarnie, finition dorée" loading="lazy" decoding="async"></div><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-montaigu-gris-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-montaigu-gris-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-montaigu-gris-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="878" alt="Plaque Le Montaigu, finition grise" loading="lazy" decoding="async"></div></div>
  <div class="tuile__texte"><div class="tuile__titre"><h3>Paysages</h3><span>5 modèles</span></div><p>Sommets, cols et cirques</p></div>
</a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="tuile" href="/produits/#patrimoine">
  <div class="tuile__mur" aria-hidden="true"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-chateau-de-mauvezin-noir-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-chateau-de-mauvezin-noir-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/le-chateau-de-mauvezin-noir-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="873" alt="Plaque Le Château de Mauvezin, finition noire" loading="lazy" decoding="async"></div><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-tour-des-jacobins-dore-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-tour-des-jacobins-dore-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-tour-des-jacobins-dore-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="864" alt="Plaque La Tour des Jacobins, finition dorée" loading="lazy" decoding="async"></div><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/labbaye-de-lescaladieu-gris-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/labbaye-de-lescaladieu-gris-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/labbaye-de-lescaladieu-gris-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="875" alt="Plaque L’Abbaye de l’Escaladieu, finition grise" loading="lazy" decoding="async"></div></div>
  <div class="tuile__texte"><div class="tuile__titre"><h3>Patrimoine</h3><span>3 modèles</span></div><p>Tour, château et abbaye</p></div>
</a>
<!-- /wp:html -->

<!-- wp:html -->
<a class="tuile" href="/produits/#faune">
  <div class="tuile__mur" aria-hidden="true"><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lours-noir-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lours-noir-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lours-noir-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="865" alt="Plaque L’Ours, finition noire" loading="lazy" decoding="async"></div><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lisard-gris-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lisard-gris-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/lisard-gris-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="870" alt="Plaque L’Isard, finition grise" loading="lazy" decoding="async"></div><div class="plaque"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-marmotte-dore-440.webp" srcset="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-marmotte-dore-440.webp 440w, <?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>p/la-marmotte-dore-880.webp 880w" sizes="(max-width: 560px) 18vw, 90px" width="440" height="870" alt="Plaque La Marmotte, finition dorée" loading="lazy" decoding="async"></div></div>
  <div class="tuile__texte"><div class="tuile__titre"><h3>Faune</h3><span>4 modèles</span></div><p>Les animaux des Pyrénées</p></div>
</a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"aussi"} -->
<div class="wp-block-group aussi">
<!-- wp:html -->
<a class="aussi__photo" href="/produits/led/" tabindex="-1" aria-hidden="true"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>led/led-img0.webp" width="858" height="1536" alt="Photo réelle : plaque L’Ours rétroéclairée en bleu par le kit LED" loading="lazy" decoding="async"></a>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"aussi__texte"} -->
<p class="aussi__texte"><strong>Le soir, en vrai</strong>Photo réelle : L’Ours rétroéclairé en bleu par le kit LED. En option à 15 € sur la fiche de chaque plaque, il est collé au dos par l’atelier. <a class="lien-fleche" href="/produits/led/">Le kit LED</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"aussi__cadeau"} -->
<p class="aussi__cadeau">Pour laisser choisir : <a href="/produits/carte-cadeau/">la carte cadeau, 65 €</a>.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section section\u002d\u002dclair tg-quand tg-quand-apres tg-quand-fini"} -->
<section class="wp-block-group section section--clair tg-quand tg-quand-apres tg-quand-fini">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"entete-section entete-section\u002d\u002dligne"} -->
<div class="wp-block-group entete-section entete-section--ligne">
<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"surtitre"} -->
<p class="surtitre">La sélection de l’atelier</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Nos coups de cœur</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"attenue petit"} -->
<p class="attenue petit">Choisissez une pastille pour voir une autre finition.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:shortcode -->
[tg_produits slugs="le-pic-du-midi,lours,lisard,le-cerf" finitions="le-pic-du-midi:noir,lours:noir,lisard:dore,le-cerf:gris"]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section section\u002d\u002dtopo apercu-carte"} -->
<section class="wp-block-group section section--topo apercu-carte">
<!-- wp:group {"className":"wrap apercu-carte__grille"} -->
<div class="wp-block-group wrap apercu-carte__grille">
<!-- wp:group {"className":"apercu-carte__tete"} -->
<div class="wp-block-group apercu-carte__tete">
<!-- wp:paragraph {"className":"surtitre"} -->
<p class="surtitre">La carte des lieux</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"titre-apercu-carte"} -->
<h2 id="titre-apercu-carte" class="wp-block-heading">Huit lieux à accrocher</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"chapo"} -->
<p class="chapo">Chaque paysage et chaque monument a son repère. L’étoile marque le décor d’origine, à Aquensis.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<figure class="apercu-carte__figure">
      <div class="atlas atlas--apercu" style="aspect-ratio:737 / 970">
  <svg class="atlas__svg" viewBox="0 0 737 970" aria-hidden="true" focusable="false">
  <defs><clipPath id="dep-apercu"><path d="M177, 382L163, 384L149, 353L152, 339L160, 331L164, 319L170, 315L187, 324L182, 340L194, 353L194, 362L185, 373L183, 370L176, 375L177, 382ZM176, 266L173, 254L184, 251L191, 254L191, 259L204, 270L206, 278L202, 312L197, 318L181, 311L171, 313L167, 293L172, 287L184, 292L189, 289L186, 266L176, 266ZM181, 43L181, 36L197, 33L198, 19L212, 19L219, 12L223, 19L227, 17L227, 21L241, 20L249, 40L250, 59L258, 65L264, 82L273, 80L283, 91L289, 106L304, 105L310, 101L317, 115L326, 114L325, 112L334, 108L337, 110L337, 115L347, 130L344, 133L350, 159L361, 160L373, 181L352, 191L348, 201L357, 210L363, 225L379, 222L383, 243L381, 248L385, 254L397, 250L402, 257L412, 255L421, 257L433, 248L439, 248L455, 239L469, 237L471, 252L475, 257L482, 258L489, 251L490, 252L494, 282L506, 276L538, 269L537, 275L543, 275L540, 275L540, 291L554, 296L575, 297L576, 284L604, 293L612, 300L622, 291L647, 298L654, 295L655, 299L662, 300L663, 304L669, 305L672, 302L683, 311L687, 309L716, 324L715, 331L701, 336L700, 348L687, 351L673, 366L674, 371L665, 373L656, 387L666, 393L670, 392L670, 405L654, 416L649, 412L643, 417L629, 413L621, 427L631, 431L636, 427L633, 433L608, 460L595, 467L574, 494L591, 507L582, 514L609, 510L610, 516L618, 518L615, 522L617, 529L640, 532L640, 542L656, 546L656, 551L663, 551L655, 560L661, 565L661, 578L665, 588L662, 589L651, 580L644, 583L643, 606L636, 616L637, 620L640, 617L639, 622L646, 624L664, 605L671, 603L678, 606L679, 602L684, 603L685, 590L694, 590L702, 604L701, 614L710, 625L707, 635L698, 636L703, 653L716, 656L723, 664L720, 672L715, 673L709, 683L694, 691L689, 698L688, 711L679, 724L672, 754L662, 764L656, 765L653, 760L642, 764L635, 757L618, 757L614, 749L611, 751L607, 747L600, 747L596, 755L597, 766L588, 773L593, 778L584, 808L584, 815L590, 821L590, 835L584, 853L590, 865L589, 886L586, 890L579, 891L605, 915L604, 922L593, 930L570, 935L546, 929L540, 925L538, 912L526, 911L515, 901L504, 914L489, 920L486, 941L480, 941L467, 952L444, 932L447, 925L441, 909L434, 907L417, 908L402, 896L380, 888L371, 896L370, 902L351, 903L349, 909L336, 914L329, 914L318, 908L309, 910L303, 921L294, 927L287, 929L270, 922L262, 923L262, 932L253, 939L240, 940L216, 931L210, 933L206, 929L202, 907L174, 904L170, 898L173, 893L166, 887L162, 873L151, 858L142, 856L144, 849L139, 844L139, 832L134, 827L124, 839L114, 838L108, 830L96, 829L91, 822L88, 824L77, 816L74, 802L65, 806L51, 797L50, 789L28, 784L23, 776L28, 755L21, 743L21, 728L14, 721L13, 709L25, 706L27, 699L34, 694L43, 696L46, 691L46, 674L40, 664L42, 658L38, 632L42, 619L50, 619L62, 611L65, 599L61, 592L63, 587L77, 585L88, 591L99, 583L106, 582L113, 573L119, 572L106, 561L109, 551L116, 541L116, 533L107, 527L112, 519L110, 510L124, 515L130, 503L145, 497L149, 489L147, 482L151, 481L151, 476L160, 467L159, 460L166, 445L171, 446L174, 459L181, 458L182, 448L202, 448L198, 403L206, 403L216, 408L218, 392L234, 371L233, 364L239, 355L239, 350L232, 349L234, 345L219, 340L218, 324L230, 309L233, 295L249, 293L259, 300L273, 279L256, 261L258, 258L255, 253L253, 256L248, 252L252, 241L250, 238L255, 231L249, 232L251, 229L249, 227L259, 203L248, 193L250, 180L240, 181L234, 195L227, 192L220, 215L203, 215L206, 207L215, 205L200, 190L207, 173L204, 161L238, 160L239, 153L226, 150L226, 136L216, 133L222, 112L219, 100L211, 92L207, 83L204, 84L204, 77L193, 78L187, 83L183, 81L187, 68L181, 43Z"/></clipPath></defs>
  <path class="atlas__dep" d="M177, 382L163, 384L149, 353L152, 339L160, 331L164, 319L170, 315L187, 324L182, 340L194, 353L194, 362L185, 373L183, 370L176, 375L177, 382ZM176, 266L173, 254L184, 251L191, 254L191, 259L204, 270L206, 278L202, 312L197, 318L181, 311L171, 313L167, 293L172, 287L184, 292L189, 289L186, 266L176, 266ZM181, 43L181, 36L197, 33L198, 19L212, 19L219, 12L223, 19L227, 17L227, 21L241, 20L249, 40L250, 59L258, 65L264, 82L273, 80L283, 91L289, 106L304, 105L310, 101L317, 115L326, 114L325, 112L334, 108L337, 110L337, 115L347, 130L344, 133L350, 159L361, 160L373, 181L352, 191L348, 201L357, 210L363, 225L379, 222L383, 243L381, 248L385, 254L397, 250L402, 257L412, 255L421, 257L433, 248L439, 248L455, 239L469, 237L471, 252L475, 257L482, 258L489, 251L490, 252L494, 282L506, 276L538, 269L537, 275L543, 275L540, 275L540, 291L554, 296L575, 297L576, 284L604, 293L612, 300L622, 291L647, 298L654, 295L655, 299L662, 300L663, 304L669, 305L672, 302L683, 311L687, 309L716, 324L715, 331L701, 336L700, 348L687, 351L673, 366L674, 371L665, 373L656, 387L666, 393L670, 392L670, 405L654, 416L649, 412L643, 417L629, 413L621, 427L631, 431L636, 427L633, 433L608, 460L595, 467L574, 494L591, 507L582, 514L609, 510L610, 516L618, 518L615, 522L617, 529L640, 532L640, 542L656, 546L656, 551L663, 551L655, 560L661, 565L661, 578L665, 588L662, 589L651, 580L644, 583L643, 606L636, 616L637, 620L640, 617L639, 622L646, 624L664, 605L671, 603L678, 606L679, 602L684, 603L685, 590L694, 590L702, 604L701, 614L710, 625L707, 635L698, 636L703, 653L716, 656L723, 664L720, 672L715, 673L709, 683L694, 691L689, 698L688, 711L679, 724L672, 754L662, 764L656, 765L653, 760L642, 764L635, 757L618, 757L614, 749L611, 751L607, 747L600, 747L596, 755L597, 766L588, 773L593, 778L584, 808L584, 815L590, 821L590, 835L584, 853L590, 865L589, 886L586, 890L579, 891L605, 915L604, 922L593, 930L570, 935L546, 929L540, 925L538, 912L526, 911L515, 901L504, 914L489, 920L486, 941L480, 941L467, 952L444, 932L447, 925L441, 909L434, 907L417, 908L402, 896L380, 888L371, 896L370, 902L351, 903L349, 909L336, 914L329, 914L318, 908L309, 910L303, 921L294, 927L287, 929L270, 922L262, 923L262, 932L253, 939L240, 940L216, 931L210, 933L206, 929L202, 907L174, 904L170, 898L173, 893L166, 887L162, 873L151, 858L142, 856L144, 849L139, 844L139, 832L134, 827L124, 839L114, 838L108, 830L96, 829L91, 822L88, 824L77, 816L74, 802L65, 806L51, 797L50, 789L28, 784L23, 776L28, 755L21, 743L21, 728L14, 721L13, 709L25, 706L27, 699L34, 694L43, 696L46, 691L46, 674L40, 664L42, 658L38, 632L42, 619L50, 619L62, 611L65, 599L61, 592L63, 587L77, 585L88, 591L99, 583L106, 582L113, 573L119, 572L106, 561L109, 551L116, 541L116, 533L107, 527L112, 519L110, 510L124, 515L130, 503L145, 497L149, 489L147, 482L151, 481L151, 476L160, 467L159, 460L166, 445L171, 446L174, 459L181, 458L182, 448L202, 448L198, 403L206, 403L216, 408L218, 392L234, 371L233, 364L239, 355L239, 350L232, 349L234, 345L219, 340L218, 324L230, 309L233, 295L249, 293L259, 300L273, 279L256, 261L258, 258L255, 253L253, 256L248, 252L252, 241L250, 238L255, 231L249, 232L251, 229L249, 227L259, 203L248, 193L250, 180L240, 181L234, 195L227, 192L220, 215L203, 215L206, 207L215, 205L200, 190L207, 173L204, 161L238, 160L239, 153L226, 150L226, 136L216, 133L222, 112L219, 100L211, 92L207, 83L204, 84L204, 77L193, 78L187, 83L183, 81L187, 68L181, 43Z"/>
  <g class="atlas__topo" clip-path="url(#dep-apercu)"><path d="M0, 296L15, 296L20, 299L30, 309L45, 318L59, 319L69, 324L89, 327L109, 316L112, 312L112, 307L110, 302L114, 300L119, 304L124, 305L129, 305L138, 301L153, 303L158, 299L174, 282L178, 275L183, 272L190, 272L203, 278L247, 269L250, 272L252, 302L264, 317L274, 337L276, 346L275, 371L289, 401L306, 440L312, 448L317, 451L322, 450L326, 431L328, 391L326, 328L331, 306L339, 297L351, 296L366, 302L376, 299L391, 299L401, 293L406, 292L415, 294L422, 297L435, 321L450, 329L470, 325L485, 309L500, 301L524, 297L549, 301L559, 295L564, 294L579, 307L589, 313L594, 313L608, 300L623, 290L653, 281L659, 282L662, 287L663, 294L668, 296L707, 291L722, 283L737, 290M0, 436L15, 439L25, 444L40, 458L51, 465L59, 474L72, 480L75, 485L69, 489L59, 487L30, 468L0, 457M326, 480L331, 480L342, 505L345, 515L341, 520L331, 513L326, 505L324, 495L326, 480M94, 500L99, 498L114, 501L139, 515L145, 520L141, 525L134, 528L124, 526L114, 519L94, 500M613, 530L628, 526L683, 532L693, 534L705, 544L702, 548L688, 546L658, 548L618, 544L598, 551L584, 562L574, 571L569, 573L567, 569L568, 564L579, 550L598, 543L613, 530M0, 487L15, 496L40, 505L64, 516L84, 534L92, 539L124, 549L173, 538L189, 539L192, 544L192, 554L196, 564L198, 567L203, 566L208, 564L219, 554L237, 534L241, 515L241, 500L237, 497L223, 500L208, 500L193, 497L173, 490L143, 490L111, 475L103, 470L97, 460L97, 436L91, 421L94, 416L114, 414L143, 404L163, 421L173, 452L178, 455L193, 450L198, 437L203, 432L208, 434L213, 447L223, 454L232, 465L237, 467L252, 467L267, 457L287, 466L292, 470L295, 475L300, 510L304, 520L319, 539L331, 549L355, 574L366, 580L372, 574L377, 554L378, 520L374, 510L360, 490L352, 450L358, 431L364, 421L365, 411L370, 406L376, 405L381, 406L394, 421L401, 423L411, 423L425, 417L435, 416L470, 422L485, 421L500, 433L505, 433L514, 427L519, 427L525, 431L529, 439L544, 441L564, 455L579, 452L594, 461L608, 453L612, 455L614, 460L610, 470L613, 475L627, 485L627, 490L608, 500L594, 502L589, 501L569, 487L564, 486L559, 492L558, 500L559, 505L573, 515L572, 520L559, 534L549, 550L545, 579L546, 599L550, 604L559, 605L564, 604L583, 594L608, 574L620, 569L638, 568L658, 569L673, 567L702, 571L717, 568L737, 572M737, 521L727, 521L697, 512L655, 505L642, 500L629, 490L629, 485L648, 470L648, 460L651, 455L663, 451L673, 442L678, 426L683, 418L712, 410L727, 402L737, 403M0, 581L15, 581L35, 585L64, 583L104, 570L124, 568L148, 562L158, 562L163, 565L170, 574L178, 598L183, 603L188, 604L198, 599L208, 584L223, 571L237, 562L247, 558L267, 557L297, 564L312, 564L322, 567L336, 575L361, 599L376, 606L381, 606L396, 567L407, 549L411, 547L455, 538L470, 537L485, 542L509, 556L520, 564L529, 575L534, 589L535, 614L532, 633L527, 648L529, 658L534, 657L544, 638L564, 617L579, 611L608, 611L623, 598L628, 597L643, 603L668, 605L683, 604L707, 594L727, 595L737, 600M0, 633L24, 629L45, 620L89, 612L114, 599L129, 596L143, 596L153, 600L173, 620L183, 625L188, 626L223, 610L247, 608L282, 589L302, 586L317, 588L331, 592L351, 609L366, 619L396, 634L411, 637L414, 633L414, 629L409, 604L411, 593L415, 588L435, 579L445, 576L460, 576L470, 577L490, 584L505, 592L510, 599L517, 629L513, 643L511, 668L514, 685L519, 691L541, 673L559, 648L564, 643L574, 640L594, 646L623, 652L653, 676L673, 683L692, 694L697, 695L704, 693L712, 680L722, 679L732, 682L737, 681M0, 644L45, 632L64, 630L94, 622L119, 609L134, 607L147, 609L153, 611L198, 652L203, 649L208, 638L213, 632L218, 632L232, 638L242, 638L247, 635L262, 611L272, 602L287, 595L312, 593L329, 599L346, 615L391, 636L402, 643L408, 653L415, 673L425, 665L428, 658L428, 638L422, 614L425, 601L445, 592L465, 592L490, 600L495, 605L506, 624L506, 668L514, 709L519, 707L533, 688L559, 660L574, 651L579, 651L594, 658L608, 661L613, 663L625, 673L658, 694L673, 709L692, 711L702, 710L717, 715L732, 712L737, 713M204, 673L208, 668L220, 673L232, 685L234, 688L232, 693L223, 700L214, 698L204, 673M737, 868L727, 866L722, 862L720, 856L720, 851L722, 848L737, 844M0, 657L45, 640L79, 634L94, 635L109, 625L124, 619L143, 618L153, 623L168, 633L181, 648L189, 663L193, 673L211, 703L223, 708L228, 708L237, 700L247, 684L252, 682L254, 678L252, 672L246, 663L246, 653L251, 643L267, 616L283, 604L302, 600L317, 601L326, 605L346, 621L391, 640L400, 648L403, 653L411, 687L420, 679L435, 663L438, 643L434, 624L437, 614L450, 606L465, 607L475, 612L492, 629L498, 663L506, 688L509, 718L514, 726L540, 688L559, 669L569, 664L579, 662L613, 676L633, 689L644, 703L663, 717L668, 720L688, 726L702, 735L707, 740L712, 756L717, 764L722, 766L727, 765L737, 757M165, 723L173, 719L176, 723L163, 739L158, 741L154, 737L154, 732L165, 723M493, 797L495, 794L500, 794L501, 797L500, 808L495, 812L490, 807L493, 797M737, 917L732, 918L729, 916L727, 904L723, 896L724, 886L722, 883L717, 881L707, 882L703, 881L710, 866L708, 846L710, 841L717, 836L737, 832M668, 921L673, 918L678, 918L687, 921L688, 925L682, 930L673, 933L668, 930L667, 925L668, 921M692, 970L717, 966L732, 959L737, 961M0, 669L25, 654L45, 647L79, 643L94, 647L99, 646L109, 637L124, 629L134, 627L143, 627L163, 637L177, 653L185, 668L188, 694L193, 695L198, 692L204, 703L208, 706L232, 720L237, 720L254, 698L272, 693L274, 688L265, 678L256, 658L269, 624L277, 615L287, 609L307, 605L322, 609L341, 626L379, 638L396, 648L401, 663L403, 683L403, 693L406, 697L415, 692L446, 663L453, 643L450, 633L450, 628L455, 626L465, 629L475, 637L479, 643L485, 654L487, 663L500, 684L503, 698L504, 732L509, 739L514, 739L542, 693L559, 678L564, 675L574, 673L603, 680L628, 697L654, 728L668, 740L682, 747L691, 757L696, 767L697, 789L707, 793L722, 795L725, 797L727, 802L722, 805L702, 808L697, 807L692, 814L690, 826L701, 861L685, 881L658, 909L652, 921L650, 935L652, 945L658, 955L673, 965L676, 970M170, 713L183, 708L186, 713L185, 718L176, 732L163, 748L153, 748L149, 742L147, 732L158, 720L170, 713M493, 782L500, 779L505, 779L508, 782L509, 787L505, 807L500, 817L495, 820L490, 820L485, 813L483, 807L489, 787L493, 782M257, 792L258, 792L259, 797L257, 809L252, 807L252, 802L257, 792M0, 692L25, 671L45, 660L59, 659L89, 664L104, 665L119, 652L134, 645L148, 644L158, 648L165, 653L173, 665L175, 678L163, 703L140, 723L137, 728L136, 742L139, 752L140, 767L143, 770L148, 772L158, 766L168, 755L198, 714L203, 712L221, 723L238, 737L250, 752L252, 767L247, 780L242, 817L252, 855L257, 858L267, 853L271, 846L267, 831L269, 817L269, 782L267, 772L260, 757L257, 743L257, 723L262, 716L272, 710L283, 708L288, 703L294, 693L294, 683L282, 673L274, 653L276, 633L282, 625L287, 622L302, 617L312, 618L326, 627L336, 638L371, 644L386, 652L392, 663L395, 678L394, 688L388, 708L394, 713L420, 699L445, 680L460, 675L470, 675L475, 677L490, 692L495, 703L498, 757L494, 767L483, 782L474, 807L474, 822L470, 848L475, 846L505, 824L512, 807L520, 782L518, 757L519, 752L536, 718L549, 700L559, 694L579, 689L598, 693L619, 713L637, 742L649, 752L656, 772L663, 782L671, 826L670, 841L663, 852L652, 886L633, 925L629, 955L616, 970M390, 970L401, 968L414, 970M0, 704L25, 679L45, 667L54, 666L74, 667L109, 676L114, 674L119, 663L133, 653L148, 651L158, 655L169, 668L169, 678L158, 699L148, 708L134, 715L132, 718L129, 732L134, 767L143, 775L153, 776L168, 761L177, 747L198, 720L203, 717L218, 725L236, 742L244, 757L245, 772L237, 817L247, 861L252, 868L257, 867L272, 854L274, 846L272, 831L272, 787L265, 737L266, 732L272, 720L287, 712L297, 703L303, 688L301, 678L290, 668L283, 658L280, 643L284, 633L291, 629L302, 625L312, 626L324, 633L331, 645L356, 646L367, 648L378, 653L386, 661L391, 678L388, 693L378, 713L378, 718L381, 723L386, 724L445, 687L460, 683L470, 683L475, 686L490, 701L492, 708L493, 752L489, 767L479, 782L470, 807L469, 822L459, 861L460, 866L465, 868L475, 861L485, 845L507, 826L523, 787L524, 752L544, 714L559, 701L579, 696L591, 698L599, 703L608, 717L622, 732L628, 745L638, 752L642, 757L644, 772L650, 782L652, 797L659, 812L663, 826L660, 836L654, 846L648, 876L626, 925L621, 945L618, 951L602, 970M379, 970L389, 960L420, 959L435, 952L455, 949L470, 951L479, 970M0, 715L10, 707L25, 687L45, 674L54, 672L74, 673L103, 683L112, 688L124, 703L121, 728L124, 752L128, 767L138, 777L148, 780L158, 777L168, 767L178, 750L198, 725L203, 722L213, 726L231, 742L240, 757L240, 782L237, 799L232, 812L233, 822L243, 866L247, 874L252, 876L257, 875L272, 860L277, 851L274, 802L275, 787L271, 757L272, 736L277, 726L305, 708L310, 688L307, 669L292, 655L289, 648L289, 643L292, 638L297, 635L307, 633L312, 635L320, 643L324, 653L326, 654L351, 651L361, 652L376, 659L385, 668L387, 678L386, 688L370, 713L371, 728L376, 731L386, 731L411, 713L435, 698L450, 692L465, 689L470, 690L485, 703L487, 708L490, 737L487, 762L474, 787L465, 807L464, 822L453, 861L455, 869L460, 873L465, 875L470, 874L475, 870L490, 847L505, 835L511, 826L527, 787L528, 752L538, 737L547, 718L559, 708L574, 703L584, 704L596, 713L606, 728L615, 737L628, 762L630, 772L643, 802L644, 812L652, 826L653, 831L646, 846L642, 871L635, 886L627, 911L618, 925L615, 940L612, 945L594, 962L581, 970M134, 663L143, 659L153, 661L161, 668L162, 673L158, 686L153, 692L134, 699L131, 698L125, 683L127, 673L134, 663M366, 970L381, 948L386, 947L396, 952L411, 952L425, 945L440, 944L455, 940L470, 944L475, 947L485, 964L491, 970M0, 726L15, 714L26, 693L35, 685L49, 679L79, 680L103, 693L107, 698L117, 742L117, 757L122, 767L134, 778L148, 784L158, 782L173, 767L180, 752L198, 730L203, 727L213, 731L228, 745L236, 757L237, 782L232, 800L228, 810L228, 817L232, 836L233, 851L237, 866L242, 878L247, 882L252, 882L264, 876L279, 856L280, 841L278, 826L275, 757L278, 737L282, 732L313, 713L316, 688L315, 678L316, 673L320, 668L331, 662L346, 658L356, 658L366, 660L376, 665L382, 673L381, 688L367, 708L364, 718L365, 728L376, 736L386, 736L411, 717L435, 702L445, 699L465, 696L475, 700L482, 708L486, 737L483, 762L460, 807L459, 822L449, 861L451, 871L460, 879L465, 880L476, 876L492, 851L508, 836L514, 828L532, 792L534, 782L534, 752L543, 737L550, 723L555, 718L564, 714L579, 712L594, 722L612, 747L618, 762L625, 797L643, 831L639, 846L637, 866L626, 886L619, 911L610, 925L607, 940L574, 964L552, 970M0, 918L3, 925L3, 955L9, 970M356, 970L363, 960L371, 942L376, 936L381, 935L406, 945L420, 938L440, 938L455, 935L475, 937L490, 956L505, 966L514, 969L533, 970M0, 750L7, 737L25, 721L39, 698L45, 693L54, 690L79, 693L92, 703L102, 737L101, 752L107, 767L111, 772L138, 788L153, 791L163, 786L178, 773L188, 752L201, 737L203, 736L208, 737L225, 757L229, 767L227, 782L213, 802L215, 817L221, 836L222, 871L232, 891L242, 898L247, 898L267, 883L286, 861L286, 841L282, 802L282, 762L284, 752L291, 742L327, 718L326, 708L327, 698L330, 688L337, 678L346, 671L361, 670L367, 673L371, 678L371, 683L367, 693L357, 708L353, 723L354, 728L371, 744L388, 752L392, 752L396, 742L413, 728L440, 712L455, 709L465, 710L470, 713L475, 721L479, 737L475, 764L453, 797L445, 802L440, 802L438, 807L445, 812L447, 822L441, 856L442, 876L455, 894L470, 898L477, 896L485, 891L491, 881L501, 856L520, 836L534, 813L548, 802L554, 784L569, 772L565, 767L554, 762L550, 757L550, 752L553, 747L564, 735L569, 734L579, 738L588, 747L591, 757L591, 762L603, 776L613, 797L624, 851L622, 861L613, 869L608, 876L609, 896L598, 921L586, 940L564, 954L529, 956L514, 951L505, 945L495, 934L480, 912L475, 918L470, 920L450, 924L435, 924L420, 919L386, 915L375, 911L366, 900L351, 955L341, 970M398, 777L401, 775L411, 782L420, 784L435, 799L440, 802L434, 807L421, 812L412, 822L391, 828L388, 812L391, 802L391, 787L393, 782L398, 777M0, 820L6, 831L7, 846L20, 861L17, 891L23, 925L27, 940L27, 955L30, 970M0, 767L14, 737L26, 728L45, 703L54, 698L69, 698L80, 703L84, 708L94, 736L94, 742L90, 752L92, 757L107, 777L138, 792L153, 794L163, 791L181, 777L190, 757L203, 742L208, 744L222, 762L223, 767L219, 782L207, 797L206, 802L210, 826L216, 846L215, 861L217, 881L219, 886L247, 914L252, 911L263, 891L272, 884L290, 861L285, 807L288, 757L292, 751L302, 742L326, 726L336, 723L335, 708L342, 688L351, 679L359, 678L362, 683L361, 688L349, 708L344, 723L366, 746L392, 767L386, 782L383, 812L385, 836L396, 839L406, 835L420, 834L428, 822L435, 819L437, 822L439, 831L434, 846L434, 876L436, 881L450, 906L449, 911L445, 913L437, 916L430, 915L419, 911L406, 902L396, 904L386, 901L371, 878L366, 876L351, 883L349, 886L353, 896L349, 930L344, 955L333, 970M447, 718L455, 716L465, 719L471, 728L475, 742L471, 762L466, 772L455, 781L445, 785L415, 774L401, 763L399, 757L402, 747L416, 732L425, 727L447, 718M581, 782L589, 782L594, 785L604, 797L605, 802L604, 812L613, 841L612, 851L604, 861L598, 871L600, 896L590, 921L575, 940L559, 946L534, 946L524, 943L510, 935L501, 925L500, 911L493, 901L493, 891L499, 881L502, 866L508, 856L528, 836L534, 826L556, 812L559, 797L563, 792L581, 782M0, 795L5, 812L15, 826L20, 846L30, 856L32, 861L26, 881L28, 906L40, 935L44, 955L55, 970M123, 970L124, 964L117, 960L119, 945L124, 940L134, 939L138, 940L138, 951L136, 955L143, 970M73, 970L86, 970M158, 970L148, 961L146, 955L146, 935L143, 928L134, 926L119, 933L89, 954L79, 957L61, 945L58, 940L51, 921L40, 911L37, 906L35, 891L36, 876L40, 868L49, 856L40, 851L36, 846L27, 826L16, 812L8, 797L5, 787L5, 777L9, 762L19, 742L34, 728L45, 713L54, 707L59, 706L69, 708L74, 711L78, 718L85, 737L83, 752L94, 772L104, 784L114, 786L134, 795L153, 799L163, 796L188, 782L193, 766L198, 757L203, 753L210, 757L215, 767L213, 773L207, 782L195, 792L198, 802L198, 817L201, 831L209, 846L210, 886L213, 892L223, 898L232, 908L240, 921L247, 937L252, 941L257, 942L263, 935L261, 911L267, 896L282, 877L295, 866L288, 807L292, 787L294, 762L296, 757L307, 746L328, 732L336, 729L341, 729L347, 732L370, 757L379, 772L380, 787L378, 802L378, 831L382, 846L391, 857L392, 866L382, 866L376, 860L366, 867L346, 873L336, 881L341, 896L340, 930L335, 950L325, 965L316, 970M447, 728L455, 725L461, 728L467, 737L469, 747L466, 762L463, 767L455, 774L445, 775L435, 773L420, 766L410, 757L410, 752L421, 737L447, 728M577, 817L584, 814L589, 817L598, 826L601, 831L600, 846L588, 866L591, 891L585, 916L569, 932L559, 937L544, 937L524, 932L515, 925L509, 909L500, 896L501, 891L508, 881L509, 866L514, 858L529, 844L544, 841L572, 826L577, 817M400, 876L406, 871L411, 871L415, 874L416, 876L415, 881L411, 884L406, 884L401, 881L400, 876M172, 970L156, 955L151, 925L143, 918L124, 915L120, 911L117, 896L114, 890L104, 889L97, 891L96, 896L99, 901L111, 921L104, 925L84, 927L74, 920L69, 921L62, 911L52, 906L48, 901L44, 891L46, 876L50, 871L59, 867L74, 867L77, 861L84, 855L86, 846L74, 831L59, 835L45, 823L31, 817L15, 795L12, 782L15, 767L25, 748L40, 732L49, 719L54, 717L64, 720L72, 728L74, 737L72, 747L83, 772L94, 786L97, 797L99, 799L114, 798L153, 805L173, 800L181, 802L183, 818L202, 846L202, 861L204, 891L207, 896L223, 907L232, 918L237, 925L240, 940L247, 948L257, 951L267, 945L270, 935L267, 916L269, 906L273, 896L287, 880L297, 874L302, 874L320, 886L332, 911L330, 940L329, 945L319, 960L305, 970M336, 737L341, 738L346, 741L361, 755L367, 762L373, 777L375, 787L371, 807L373, 817L372, 831L373, 846L371, 852L361, 856L351, 857L326, 873L307, 866L302, 861L292, 823L291, 807L298, 787L300, 767L304, 757L312, 749L336, 737M568, 841L579, 841L585, 846L583, 851L575, 861L582, 876L582, 881L576, 891L575, 896L580, 906L579, 911L574, 917L564, 923L554, 927L544, 927L529, 921L525, 916L519, 896L525, 886L524, 866L529, 862L534, 854L551, 851L568, 841M322, 762L331, 759L341, 760L356, 770L359, 777L361, 792L360, 807L361, 822L356, 835L336, 847L326, 850L317, 847L307, 839L302, 830L299, 817L302, 803L309, 792L312, 777L322, 762M33, 772L35, 769L40, 772L35, 773L33, 772M193, 970L182, 960L170, 940L173, 921L178, 911L177, 906L168, 897L163, 900L158, 900L152, 896L134, 872L130, 861L123, 856L120, 851L124, 844L138, 831L143, 829L148, 835L153, 846L153, 863L156, 861L157, 856L154, 851L161, 846L178, 846L185, 851L191, 881L182, 896L180, 906L193, 906L203, 909L213, 914L219, 921L228, 935L236, 970M282, 911L287, 907L292, 907L297, 909L301, 916L310, 940L307, 950L302, 956L292, 958L288, 955L285, 925L281, 916L282, 911M249, 970L262, 965L277, 963L282, 964L283, 970M324, 772L331, 768L346, 774L351, 778L354, 787L354, 797L352, 802L354, 817L352, 826L342, 836L331, 841L322, 841L312, 836L307, 828L305, 822L308, 807L315, 797L318, 782L324, 772M204, 970L188, 954L180, 935L180, 925L183, 919L188, 916L193, 916L208, 919L222, 935L225, 945L223, 955L225, 970"/><path class="atlas__topo-fort" d="M0, 609L30, 605L79, 601L88, 599L99, 591L114, 585L129, 583L148, 583L153, 583L158, 587L178, 613L188, 615L203, 608L218, 594L232, 586L287, 578L302, 578L322, 581L331, 584L371, 614L388, 624L396, 624L400, 619L396, 599L397, 594L406, 581L415, 571L426, 564L440, 560L455, 560L480, 564L493, 569L509, 579L520, 589L523, 599L525, 614L518, 663L519, 670L524, 675L529, 674L539, 666L552, 643L559, 635L569, 628L574, 627L589, 629L603, 634L610, 633L623, 629L628, 630L643, 640L651, 648L668, 654L673, 653L688, 644L712, 647L722, 651L737, 642M0, 680L30, 659L45, 653L64, 652L99, 656L104, 654L114, 645L134, 636L143, 636L158, 641L168, 649L177, 663L180, 668L180, 678L172, 703L153, 718L144, 728L142, 732L143, 742L148, 760L153, 760L168, 749L198, 708L203, 707L232, 727L242, 731L246, 728L250, 718L262, 704L277, 701L282, 697L286, 688L272, 673L267, 663L266, 653L270, 633L276, 624L287, 615L297, 612L307, 611L317, 613L341, 632L371, 639L389, 648L395, 658L398, 668L399, 683L397, 698L398, 703L401, 704L420, 694L435, 680L450, 671L465, 666L470, 666L480, 671L490, 680L497, 693L499, 703L500, 737L505, 748L509, 753L514, 751L532, 718L549, 692L574, 682L589, 683L603, 688L628, 707L638, 723L643, 736L653, 742L663, 751L673, 756L678, 767L675, 782L679, 797L680, 826L685, 856L680, 866L650, 906L642, 921L640, 930L640, 945L643, 965L648, 968L656, 970M502, 767L509, 763L514, 772L516, 782L509, 807L505, 817L500, 823L485, 832L480, 831L478, 807L484, 787L490, 778L502, 767M256, 777L262, 775L266, 787L264, 802L264, 817L257, 836L252, 833L248, 826L246, 812L252, 782L256, 777M257, 841L262, 840L263, 846L257, 841M0, 737L20, 718L30, 698L40, 689L54, 684L79, 686L90, 693L100, 703L110, 742L110, 757L114, 766L134, 782L143, 786L153, 787L163, 782L173, 772L184, 752L198, 735L203, 731L208, 732L215, 737L228, 752L233, 762L232, 783L228, 797L220, 807L221, 812L227, 836L228, 862L240, 886L247, 888L257, 885L267, 878L283, 856L278, 757L282, 744L287, 737L318, 718L322, 688L331, 672L341, 666L351, 664L366, 666L376, 673L377, 683L373, 693L362, 708L359, 718L360, 728L376, 741L386, 741L391, 739L411, 723L440, 705L465, 703L474, 708L478, 713L483, 737L480, 762L460, 798L453, 807L453, 826L445, 861L446, 871L449, 876L455, 882L465, 888L475, 885L484, 876L499, 851L518, 831L529, 809L538, 797L545, 777L539, 758L540, 752L556, 728L563, 723L569, 722L584, 728L601, 747L611, 767L614, 782L620, 802L629, 817L629, 826L632, 836L632, 861L628, 870L619, 881L615, 901L596, 940L589, 947L564, 961L529, 963L514, 961L509, 958L491, 945L480, 930L475, 928L435, 931L420, 927L406, 932L376, 923L371, 925L368, 930L356, 960L349, 970M399, 792L401, 789L406, 789L413, 792L422, 802L411, 811L396, 815L395, 812L399, 792M0, 852L9, 861L6, 881L12, 916L13, 955L19, 970M43, 742L49, 740L54, 741L61, 747L77, 787L64, 817L59, 815L57, 807L49, 798L35, 802L27, 797L21, 787L20, 777L25, 762L43, 742M326, 752L341, 749L351, 755L363, 767L368, 787L366, 807L367, 817L364, 836L356, 845L326, 860L317, 859L307, 851L297, 828L295, 817L297, 802L303, 792L305, 777L312, 759L317, 754L326, 752M183, 970L172, 960L163, 945L161, 930L163, 921L154, 911L137, 901L124, 884L114, 879L104, 877L99, 871L99, 846L91, 831L92, 826L94, 824L99, 824L109, 829L114, 828L119, 824L124, 815L138, 811L147, 812L163, 818L173, 830L183, 835L193, 846L195, 851L197, 896L218, 911L227, 921L232, 930L237, 952L242, 955L257, 958L267, 955L272, 952L276, 945L277, 940L273, 916L277, 901L287, 891L297, 889L307, 891L313, 901L321, 940L314, 955L295, 970M557, 861L564, 859L567, 866L566, 876L560, 891L565, 906L564, 911L554, 916L549, 916L544, 914L541, 906L543, 886L542, 876L554, 866L557, 861M70, 891L74, 886L79, 887L83, 891L83, 896L79, 899L74, 898L72, 896L70, 891"/></g>
  <path class="atlas__limite" d="M177, 382L163, 384L149, 353L152, 339L160, 331L164, 319L170, 315L187, 324L182, 340L194, 353L194, 362L185, 373L183, 370L176, 375L177, 382ZM176, 266L173, 254L184, 251L191, 254L191, 259L204, 270L206, 278L202, 312L197, 318L181, 311L171, 313L167, 293L172, 287L184, 292L189, 289L186, 266L176, 266ZM181, 43L181, 36L197, 33L198, 19L212, 19L219, 12L223, 19L227, 17L227, 21L241, 20L249, 40L250, 59L258, 65L264, 82L273, 80L283, 91L289, 106L304, 105L310, 101L317, 115L326, 114L325, 112L334, 108L337, 110L337, 115L347, 130L344, 133L350, 159L361, 160L373, 181L352, 191L348, 201L357, 210L363, 225L379, 222L383, 243L381, 248L385, 254L397, 250L402, 257L412, 255L421, 257L433, 248L439, 248L455, 239L469, 237L471, 252L475, 257L482, 258L489, 251L490, 252L494, 282L506, 276L538, 269L537, 275L543, 275L540, 275L540, 291L554, 296L575, 297L576, 284L604, 293L612, 300L622, 291L647, 298L654, 295L655, 299L662, 300L663, 304L669, 305L672, 302L683, 311L687, 309L716, 324L715, 331L701, 336L700, 348L687, 351L673, 366L674, 371L665, 373L656, 387L666, 393L670, 392L670, 405L654, 416L649, 412L643, 417L629, 413L621, 427L631, 431L636, 427L633, 433L608, 460L595, 467L574, 494L591, 507L582, 514L609, 510L610, 516L618, 518L615, 522L617, 529L640, 532L640, 542L656, 546L656, 551L663, 551L655, 560L661, 565L661, 578L665, 588L662, 589L651, 580L644, 583L643, 606L636, 616L637, 620L640, 617L639, 622L646, 624L664, 605L671, 603L678, 606L679, 602L684, 603L685, 590L694, 590L702, 604L701, 614L710, 625L707, 635L698, 636L703, 653L716, 656L723, 664L720, 672L715, 673L709, 683L694, 691L689, 698L688, 711L679, 724L672, 754L662, 764L656, 765L653, 760L642, 764L635, 757L618, 757L614, 749L611, 751L607, 747L600, 747L596, 755L597, 766L588, 773L593, 778L584, 808L584, 815L590, 821L590, 835L584, 853L590, 865L589, 886L586, 890L579, 891L605, 915L604, 922L593, 930L570, 935L546, 929L540, 925L538, 912L526, 911L515, 901L504, 914L489, 920L486, 941L480, 941L467, 952L444, 932L447, 925L441, 909L434, 907L417, 908L402, 896L380, 888L371, 896L370, 902L351, 903L349, 909L336, 914L329, 914L318, 908L309, 910L303, 921L294, 927L287, 929L270, 922L262, 923L262, 932L253, 939L240, 940L216, 931L210, 933L206, 929L202, 907L174, 904L170, 898L173, 893L166, 887L162, 873L151, 858L142, 856L144, 849L139, 844L139, 832L134, 827L124, 839L114, 838L108, 830L96, 829L91, 822L88, 824L77, 816L74, 802L65, 806L51, 797L50, 789L28, 784L23, 776L28, 755L21, 743L21, 728L14, 721L13, 709L25, 706L27, 699L34, 694L43, 696L46, 691L46, 674L40, 664L42, 658L38, 632L42, 619L50, 619L62, 611L65, 599L61, 592L63, 587L77, 585L88, 591L99, 583L106, 582L113, 573L119, 572L106, 561L109, 551L116, 541L116, 533L107, 527L112, 519L110, 510L124, 515L130, 503L145, 497L149, 489L147, 482L151, 481L151, 476L160, 467L159, 460L166, 445L171, 446L174, 459L181, 458L182, 448L202, 448L198, 403L206, 403L216, 408L218, 392L234, 371L233, 364L239, 355L239, 350L232, 349L234, 345L219, 340L218, 324L230, 309L233, 295L249, 293L259, 300L273, 279L256, 261L258, 258L255, 253L253, 256L248, 252L252, 241L250, 238L255, 231L249, 232L251, 229L249, 227L259, 203L248, 193L250, 180L240, 181L234, 195L227, 192L220, 215L203, 215L206, 207L215, 205L200, 190L207, 173L204, 161L238, 160L239, 153L226, 150L226, 136L216, 133L222, 112L219, 100L211, 92L207, 83L204, 84L204, 77L193, 78L187, 83L183, 81L187, 68L181, 43Z"/>
</svg>
  <span class="atlas__ville atlas__ville--g" style="left:41.88%;top:40.41%" aria-hidden="true">Tarbes</span><span class="atlas__ville atlas__ville--g" style="left:29.60%;top:54.64%" aria-hidden="true">Lourdes</span><span class="atlas__pays" style="left:4.46%;top:94.33%" aria-hidden="true">Espagne</span><span class="rappel" style="left:60.89%;top:52.06%;--l:18px;--a:-49.4deg;--ml:23px;--ma:-52.1deg" aria-hidden="true"></span><a class="repere repere--plaque repere--d" href="/carte-des-lieux/#le-chateau-de-mauvezin" style="left:60.89%;top:52.06%;--dx:12px;--dy:-14px;--mdx:14px;--mdy:-18px" aria-label="Le Château de Mauvezin : voir sur la carte"><span class="repere__num">1</span><span class="repere__nom">Le Château de Mauvezin</span></a><span class="rappel" style="left:59.60%;top:53.09%;--l:13px;--a:153.4deg;--ml:5px;--ma:78.7deg" aria-hidden="true"></span><a class="repere repere--plaque repere--d" href="/carte-des-lieux/#labbaye-de-lescaladieu" style="left:59.60%;top:53.09%;--dx:-12px;--dy:6px;--mdx:1px;--mdy:5px" aria-label="L’Abbaye de l’Escaladieu : voir sur la carte"><span class="repere__num">2</span><span class="repere__nom">L’Abbaye de l’Escaladieu</span></a><span class="rappel" style="left:48.91%;top:57.73%;--l:3px;--a:-135.0deg;--ml:15px;--ma:-90.0deg" aria-hidden="true"></span><a class="repere repere--plaque repere--g" href="/carte-des-lieux/#la-tour-des-jacobins" style="left:48.91%;top:57.73%;--dx:-2px;--dy:-2px;--mdx:0px;--mdy:-15px" aria-label="La Tour des Jacobins : voir sur la carte"><span class="repere__num">3</span><span class="repere__nom">La Tour des Jacobins</span></a><span class="rappel" style="left:40.99%;top:66.08%;--l:0px;--a:0.0deg;--ml:8px;--ma:150.3deg" aria-hidden="true"></span><a class="repere repere--plaque repere--g" href="/carte-des-lieux/#le-montaigu" style="left:40.99%;top:66.08%;--dx:0px;--dy:0px;--mdx:-7px;--mdy:4px" aria-label="Le Montaigu : voir sur la carte"><span class="repere__num">4</span><span class="repere__nom">Le Montaigu</span></a><span class="rappel" style="left:48.22%;top:70.93%;--l:7px;--a:-90.0deg;--ml:9px;--ma:-77.5deg" aria-hidden="true"></span><a class="repere repere--plaque repere--d" href="/carte-des-lieux/#le-pic-du-midi" style="left:48.22%;top:70.93%;--dx:0px;--dy:-7px;--mdx:2px;--mdy:-9px" aria-label="Le Pic du Midi : voir sur la carte"><span class="repere__num">5</span><span class="repere__nom">Le Pic du Midi</span></a><span class="rappel" style="left:48.51%;top:73.81%;--l:9px;--a:90.0deg;--ml:11px;--ma:90.0deg" aria-hidden="true"></span><a class="repere repere--plaque repere--d" href="/carte-des-lieux/#le-tourmalet" style="left:48.51%;top:73.81%;--dx:0px;--dy:9px;--mdx:0px;--mdy:11px" aria-label="Le Tourmalet : voir sur la carte"><span class="repere__num">6</span><span class="repere__nom">Le Tourmalet</span></a><a class="repere repere--plaque repere--d" href="/carte-des-lieux/#le-pont-despagne" style="left:20.20%;top:79.48%" aria-label="Le Pont d’Espagne : voir sur la carte"><span class="repere__num">7</span><span class="repere__nom">Le Pont d’Espagne</span></a><a class="repere repere--plaque repere--d" href="/carte-des-lieux/#le-cirque-de-gavarnie" style="left:33.17%;top:95.88%" aria-label="Le Cirque de Gavarnie : voir sur la carte"><span class="repere__num">8</span><span class="repere__nom">Le Cirque de Gavarnie</span></a><span class="rappel" style="left:48.61%;top:57.94%;--l:30px;--a:137.7deg;--ml:24px;--ma:165.4deg" aria-hidden="true"></span><a class="repere repere--vrai repere--g" href="/carte-des-lieux/#aquensis" style="left:48.61%;top:57.94%;--dx:-22px;--dy:20px;--mdx:-23px;--mdy:6px" aria-label="Aquensis : voir sur la carte"><svg class="repere__etoile" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M8 1 9.9 5.6 14.7 5.9 11 9.1 12.2 13.9 8 11.3 3.8 13.9 5 9.1 1.3 5.9 6.1 5.6Z"/></svg><span class="repere__nom">Aquensis</span></a><a class="repere repere--bientot repere--d" href="/carte-des-lieux/#le-jardin-massey" style="left:41.48%;top:40.10%" aria-label="Le Jardin Massey (en préparation) : voir sur la carte"><span class="repere__nom">Le Jardin Massey (en préparation)</span></a>
</div>
      <figcaption>Positions indicatives. Les quatre animaux de la collection n’ont pas de repère.</figcaption>
    </figure>
<!-- /wp:html -->

<!-- wp:group {"className":"apercu-carte__suite"} -->
<div class="wp-block-group apercu-carte__suite">
<!-- wp:html -->
<ol class="apercu-carte__liste"><li><span class="apercu-carte__num" aria-hidden="true">1</span><a href="/carte-des-lieux/#le-chateau-de-mauvezin">Le Château de Mauvezin</a></li><li><span class="apercu-carte__num" aria-hidden="true">2</span><a href="/carte-des-lieux/#labbaye-de-lescaladieu">L’Abbaye de l’Escaladieu</a></li><li><span class="apercu-carte__num" aria-hidden="true">3</span><a href="/carte-des-lieux/#la-tour-des-jacobins">La Tour des Jacobins</a></li><li><span class="apercu-carte__num" aria-hidden="true">4</span><a href="/carte-des-lieux/#le-montaigu">Le Montaigu</a></li><li><span class="apercu-carte__num" aria-hidden="true">5</span><a href="/carte-des-lieux/#le-pic-du-midi">Le Pic du Midi</a></li><li><span class="apercu-carte__num" aria-hidden="true">6</span><a href="/carte-des-lieux/#le-tourmalet">Le Tourmalet</a></li><li><span class="apercu-carte__num" aria-hidden="true">7</span><a href="/carte-des-lieux/#le-pont-despagne">Le Pont d’Espagne</a></li><li><span class="apercu-carte__num" aria-hidden="true">8</span><a href="/carte-des-lieux/#le-cirque-de-gavarnie">Le Cirque de Gavarnie</a></li></ol>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p><a class="btn btn--ligne" href="/carte-des-lieux/">Ouvrir la carte</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section section\u002d\u002dsauge atelier-accueil"} -->
<section class="wp-block-group section section--sauge atelier-accueil">
<!-- wp:group {"className":"wrap"} -->
<div class="wp-block-group wrap">
<!-- wp:group {"className":"origine"} -->
<div class="wp-block-group origine">
<!-- wp:html -->
<figure class="origine__photo">
        <img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>misc/aquensis.webp" width="1400" height="788" alt="Le bassin d’Aquensis à Bagnères-de-Bigorre ; au-dessus, une rangée de panneaux en métal découpé, rétroéclairés : le décor d’origine" loading="lazy" decoding="async">
        <figcaption>Photo réelle · Aquensis, Bagnères-de-Bigorre : le décor d’origine, rétroéclairé, au-dessus des bassins.</figcaption>
      </figure>
<!-- /wp:html -->

<!-- wp:group {"className":"origine__texte"} -->
<div class="wp-block-group origine__texte">
<!-- wp:paragraph {"className":"surtitre"} -->
<p class="surtitre">L’atelier · L’origine</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"titre-atelier-accueil"} -->
<h2 id="titre-atelier-accueil" class="wp-block-heading">Tout a commencé à Aquensis</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Au centre thermal de Bagnères-de-Bigorre, il fallait masquer une coursive technique. Le décor conçu pour Aquensis compte 30 niches de 1 m × 2 m, fermées par des panneaux d’aluminium découpé, thermolaqué effet Corten et rétroéclairé. L’idée des plaques de 60 × 30 cm pour la maison est venue de là : les douze plaques de la collection reprennent toutes des dessins de ce décor.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a class="lien-fleche" href="/propos/#origine">Lire l’histoire</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"fabrication-accueil"} -->
<div class="wp-block-group fabrication-accueil">
<!-- wp:group {"className":"fabrication-accueil__tete"} -->
<div class="wp-block-group fabrication-accueil__tete">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Du dessin à l’expédition</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Quatre étapes, de Revel à Bagnères-de-Bigorre. <a class="lien-fleche" href="/propos/#fabrication">La fabrication en détail</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"trajet"} -->
<div class="wp-block-group trajet">
<!-- wp:html -->
<p class="trajet__ligne" aria-hidden="true"><span>Revel (31)</span><span class="trajet__tirets"></span><span>Bagnères-de-Bigorre (65)</span></p>
<!-- /wp:html -->

<!-- wp:html -->
<ol class="etapes"><li class="etape"><p class="etape__lieu">Illustratrices</p><h3>Dessin</h3><p class="etape__texte">Les dessins originaux sont signés Maude Villatte et Lola Jacquet.</p></li><li class="etape"><p class="etape__lieu">Revel (31)</p><h3>Découpe laser</h3><p class="etape__texte">Le laser découpe la feuille d’aluminium de 2 mm, jusqu’aux lettres pochoir du titre.</p></li><li class="etape"><p class="etape__lieu">Bagnères-de-Bigorre (65)</p><h3>Thermolaquage</h3><p class="etape__texte">Une peinture en poudre cuite au four : noir, gris ou doré.</p></li><li class="etape"><p class="etape__lieu">Bagnères-de-Bigorre (65)</p><h3>Contrôle et expédition</h3><p class="etape__texte">Assemblage, contrôle et envoi. Choisi en option, le kit LED est collé au dos de la plaque avant l’envoi.</p></li></ol>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","className":"section lettre","anchor":"lettre"} -->
<section id="lettre" class="wp-block-group section lettre">
<!-- wp:group {"className":"wrap lettre__grille"} -->
<div class="wp-block-group wrap lettre__grille">
<!-- wp:group {"className":"lettre__texte"} -->
<div class="wp-block-group lettre__texte">
<!-- wp:paragraph {"className":"surtitre"} -->
<p class="surtitre">Lettre d’information</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"titre-lettre"} -->
<h2 id="titre-lettre" class="wp-block-heading">Être prévenu des nouvelles plaques</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"chapo"} -->
<p class="chapo">La lettre vous prévient de chaque nouvelle plaque. Une lettre par trimestre au plus.</p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[tg_lettre]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"bientot"} -->
<div class="wp-block-group bientot">
<!-- wp:paragraph {"className":"bientot__titre"} -->
<p class="bientot__titre">Bientôt</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ul class="bientot__liste">
    <li><div class="dessin"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' ) ); ?>dessin-la-transhumance.webp" width="199" height="398" alt="Dessin « La Transhumance »" loading="lazy" decoding="async"></div><span>La Transhumance</span></li>
    <li><div class="dessin dessin--vide"><span>Dessin à venir</span></div><span>Le Jardin Massey, à Tarbes</span></li>
  </ul>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"bientot__note"} -->
<p class="bientot__note">Et des grands formats de 60 × 120 cm, à 150 € : Le Cirque de Gavarnie, Le Tourmalet, Le Pont d’Espagne et Le Pic du Midi. Le dessin ci-dessus vient de la planche des dessins inédits de Maude Villatte et Lola Jacquet. Ces plaques n’existent pas encore en photo.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
